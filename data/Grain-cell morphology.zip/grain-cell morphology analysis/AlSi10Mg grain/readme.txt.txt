All the individual grain measurments can be found in the /raw data folder.

The statisitical analysis for each set-level morphology metric values (mean, standard deviation, and median) over all grains, are summarized in the Excel sheet "[FR] Grain morphology".