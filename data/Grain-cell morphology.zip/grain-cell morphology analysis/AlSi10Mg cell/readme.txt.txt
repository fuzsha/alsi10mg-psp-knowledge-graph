All the individual cell measurments can be found in the /raw data folder.

The statisitical analysis for each set-level morphology metric values (mean, standard deviation, and median) over all cells, are summarized in the Excel sheet "[FR] Cell morphology".