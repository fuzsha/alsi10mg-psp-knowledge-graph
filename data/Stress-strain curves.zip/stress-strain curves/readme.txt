Qixiang Luo - 10/16/2023

Each single excel file is for 1 group of samples, ranging from processing parameter set 1 to 60.
All the stress-strain curves (axial along tensile direction, engineering) tested had been uploaded, total of 178, group1/2/3 has 60/58/60 samples, respectively.